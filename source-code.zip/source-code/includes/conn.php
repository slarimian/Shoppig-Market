<?php
#=============================#
# Database Configuration #
#=============================#

class Database
{
	# public acces variable definitions
	public $dbserver = "localhost";
	//public $dbserver = "database-1.cffmn4fl2naj.us-east-1.rds.amazonaws.com";
	public $dbname = "shopping";
	public $dbusername = "root";
	public $dbpassword = "";
	public $dbport = "3306";

	# function to open connection
	function openDB()
	{
		try {
			$connection = new PDO("mysql:host={$this->dbserver};port={$this->dbport};dbname={$this->dbname};", $this->dbusername, $this->dbpassword);
		} catch (PDOException $e) {
			die("Error, please try again");
		}
		return $connection;
	}

	function getCategory()
	{
		$query = "SELECT * FROM category";
		$stmt = $this->openDB()->prepare($query);
		$stmt->execute();
		$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
		return $rows;
	}

	function getUser($id)
	{
		$stmt = $this->openDB()->prepare("SELECT * FROM users WHERE id=:id");
		$stmt->bindParam(':id', $id);
		$stmt->execute();
		$row = $stmt->fetch(\PDO::FETCH_ASSOC);
		return $row;
	}

	#user

	function checkUserAlreadyExists($mail)
	{
		// prepared query to prevent SQL injections
		$query = "SELECT email FROM users WHERE email = :mail";
		$stmt = $this->openDB()->prepare($query);
		$stmt->bindParam(':mail', $mail);
		$stmt->execute();
		$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
		return $rows;
	}

	function loginUser($mail, $password)
	{
		//prepared query to prevent SQL injections
		$query = "SELECT * FROM users WHERE `email` = :mail";
		$stmt = $this->openDB()->prepare($query);
		$stmt->bindParam(':mail', $mail);
		$stmt->execute();
		$row = $stmt->fetch(\PDO::FETCH_ASSOC);

		if (count($row) != 0) {
			$existingHashFromDb = $row['password'];
			if (password_verify($password, $existingHashFromDb)) {
				if ($row['type'] == 0) {
					return $row['id'];
				}
			} else {
				return -1;
			}
		} else {
			return -2;
		}
	}

	function createUser($firstname, $lastname, $mail, $password)
	{
		$type = 0;
		//Check if Mail for signup already exists
		$checkMail = $this->checkUserAlreadyExists($mail);
		if (!empty($checkMail)) {
			return false;
		}

		if (empty($checkMail)) {
			// prepared query to prevent SQL injections
			$query = "INSERT INTO users(`email`, `password`, `type`, `firstname`, `lastname`) VALUES(:mail, :pass, :tp, :firstname, :lastname)";
			$stmt = $this->openDB()->prepare($query);
			$stmt->bindParam(':mail', $mail);
			$stmt->bindParam(':pass', $password);
			$stmt->bindParam(':tp', $type);
			$stmt->bindParam(':firstname', $firstname);
			$stmt->bindParam(':lastname', $lastname);
			$stmt->execute();
			return true;
		}
	}

	#Product
	function getProductsForHome()
	{
		// prepared statement to prevent SQL injections
		$query = "SELECT * FROM products limit 6";
		$stmt = $this->openDB()->prepare($query);
		$stmt->execute();
		$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
		return $rows;
	}


	function getProducts($id_cat = 0)
	{
		if ($id_cat == 0) {
			// prepared statement to prevent SQL injections
			$query = "SELECT * FROM products";
			$stmt = $this->openDB()->prepare($query);
			$stmt->execute();
			$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
			return $rows;
		} else {
			// prepared statement to prevent SQL injections
			$query = "SELECT * FROM products WHERE category_id=:id";
			$stmt = $this->openDB()->prepare($query);
			$stmt->bindParam(':id', $id_cat);
			$stmt->execute();
			$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
			return $rows;
		}
	}

	function getProductDetails($id)
	{
		// prepared query to prevent SQL injections
		$query = "SELECT * FROM products WHERE id=:id";
		$stmt = $this->openDB()->prepare($query);
		$stmt->bindParam(':id', $id);
		$stmt->execute();
		$row = $stmt->fetch(\PDO::FETCH_ASSOC);
		return $row;
	}

	# function to login user
	function addToCart($user, $code, $qut)
	{
		$product = $this->getProductDetails($code);

		if (count($product) != 0) {
			$photos = $product['photos'];
			$list_photo = explode(',', $photos);

			$image = $list_photo[0];
			$name = $product['name'];
			$price = $product['price'];
			$amount = $price * $qut;

			// prepared query to prevent SQL injections
			$query = "INSERT INTO cart(`user_id`, `product_id`, `name`, `quantity`, `image`, `price`, `amount`) VALUES(:user, :code, :pname, :qut, :picture, :price, :amount)";
			$stmt = $this->openDB()->prepare($query);
			$stmt->bindParam(':user', $user);
			$stmt->bindParam(':code', $code);
			$stmt->bindParam(':pname', $name);
			$stmt->bindParam(':qut', $qut);
			$stmt->bindParam(':picture', $image);
			$stmt->bindParam(':price', $price);
			$stmt->bindParam(':amount', $amount);
			return $stmt->execute();
		} else {
			return false;
		}
	}

	function getShoppingCart($id)
	{
		$query = "SELECT * FROM cart WHERE user_id=:id";
		$stmt = $this->openDB()->prepare($query);
		$stmt->bindParam(':id', $id);
		$stmt->execute();
		$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
		return $rows;
	}

	function deleteSingleCartItem($id, $code)
	{
		// prepared statement to prevent SQL injections
		$query = "DELETE FROM cart WHERE user_id=:id AND id =:code";
		$stmt = $this->openDB()->prepare($query);
		$stmt->bindParam(':id', $id);
		$stmt->bindParam(':code', $code);
		$stmt->execute();
	}

	function deleteWholeCart($id)
	{
		// prepared statement to prevent SQL injections
		$query = "DELETE FROM cart WHERE user_id=:id";
		$stmt = $this->openDB()->prepare($query);
		$stmt->bindParam(':id', $id);
		$stmt->execute();
	}
}
