<?php
class Details
{
    public function __construct()
    {
    }

    public function processApi()
    {
        if (isset($_REQUEST['x']) && $_REQUEST['x'] != "") {
            $link = explode("/", $_REQUEST['x']);
            return $link;
        } else {
            header("Location:/");
            exit;
        }
    }
}


include '../includes/session.php';


// Initiiate Library
$api = new Details;

list($details_str, $id_details, $slug) = $api->processApi();

if (strcmp($details_str, "details") == 0) {

    $details = $db->getProductDetails($id_details);
    $page = $details['name'];
    include '../includes/head.php';


    $photos = $details['photos'];
    $list_photo = explode(',', $photos);
?>

<body>
    <?php include '../includes/header.php'; ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <?php include '../includes/sidebar.php'; ?>
                </div>

                <div class="col-sm-9 padding-right">
                    <div class="product-details">
                        <!--product-details-->
                        <div class="col-sm-1">
                            <div class="row">
                                <?php
                                    if (count($list_photo) > 0) {
                                        foreach ($list_photo as $image) { ?>
                                <div class="gallery-item">
                                    <img class="img-responsive gallery-img"
                                        src="<?php echo ROOT_HOST ?>images/product-details/<?php echo $image ?>"
                                        alt="product image">
                                </div>
                                <?php
                                        }
                                    }
                                    ?>
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="row"><img id="expandedImg" class="img-responsive"
                                    src="<?php echo ROOT_HOST ?>images/product-details/<?php echo $list_photo[0] ?>">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="product-information">
                                <!--/product-information-->
                                <img src="images/product-details/new.jpg" class="newarrival" alt="" />
                                <h2><?php echo $details['name'] ?></h2>
                                <p>Web ID:esp153 <?php echo $details['id'] ?></p>
                                <div class="rating">
                                    <?php
                                        $av = intval($details['score']);
                                        for ($i = 1; $i <= 5; $i++) { ?>
                                    <i class="fa fa-star <?php if ($i <= $av) {
                                                                        echo "filled";
                                                                    } ?>"></i>
                                    <?php } ?>
                                </div>
                                <span>
                                    <span><?php echo $details['price'] . " €" ?></span>
                                    <label>Quantity:</label>
                                    <input id="qut" name="qut" type="number" value="1" min="1" max="10"
                                        product="<?php echo $details['id'] ?>" />
                                    <button type="button" class="btn btn-fefault cart add-cart">
                                        <i class="fa fa-shopping-cart"></i>
                                        Add to cart
                                    </button>
                                </span>
                                <p><b>Availability:</b><?php if ($details['availability'] == 1) echo "In Stock";
                                                            else "َUnavailable" ?>
                                </p>
                                <p><b>Condition:</b>
                                    <?php if ($details['new'] == 1) echo "New";
                                        elseif ($details['sale'] == 1) echo "Sale";
                                        else echo "--" ?>
                                </p>
                                <p><b>Brand:</b> E-SHOPPER</p>
                            </div>
                            <!--/product-information-->
                        </div>
                    </div>
                    <!--/product-details-->
                </div>
            </div>
        </div>
    </section>

    <?php
        include '../includes/footer.php';
        include '../includes/scripts.php';
        ?>
</body>

</html>

<?php

} else {
    header("Location:/");
}

?>