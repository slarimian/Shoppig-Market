<?php
include 'includes/session.php';

if (isset($_POST['signup'])) {
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$repassword = $_POST['repassword'];

	$_SESSION['firstname'] = $firstname;
	$_SESSION['lastname'] = $lastname;
	$_SESSION['email'] = $email;

	if (!preg_match("/^[a-zA-Z-' ]*$/", $firstname)) {
		$_SESSION['error'] = 'Firstname Only letters and white space allowed';
		header('location:' . ROOT_HOST  . 'login.php');
	} elseif (!preg_match("/^[a-zA-Z-' ]*$/", $lastname)) {
		$_SESSION['error'] = 'Lastname Only letters and white space allowed';
		header('location:' . ROOT_HOST  . 'login.php');
	} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		$_SESSION['error'] = 'Invalid email format';
		header('location:' . ROOT_HOST  . 'login.php');
	} elseif (strlen($password) < 6) {
		$_SESSION['error'] = 'Password should be at least 6 characters in length';
		header('location:' . ROOT_HOST  . 'login.php');
	} elseif ($password != $repassword) {
		$_SESSION['error'] = 'Passwords did not match';
		header('location:' . ROOT_HOST  . 'login.php');
	} else {
		$option = [
			"cost" => "10"
		];
		$password_hash = password_hash($password, PASSWORD_BCRYPT, $option);

		$result = $db->createUser($firstname, $lastname, $email, $password_hash);
		if ($result == 1) {
			unset($_SESSION['firstname']);
			unset($_SESSION['lastname']);
			unset($_SESSION['email']);
			$_SESSION['success'] = 'Your account has been successfully created. Now you can login to your account';
			header('location:' . ROOT_HOST  . 'login.php');
		}

		if ($result == 0) {
			$_SESSION['error'] = 'Email already taken';
			header('location:' . ROOT_HOST  . 'login.php');
		}
	}
} else {
	$_SESSION['error'] = 'Fill up signup form first';
	header('location:' . ROOT_HOST  . 'login.php');
}
