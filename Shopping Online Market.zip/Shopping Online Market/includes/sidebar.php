<div class="left-sidebar">
    <h2>Category</h2>
    <div class="panel-group category-products" id="accordian">
        <!--category-productsr-->

        <?php
		$items = $db->getCategory();
		foreach ($items as $category) {
		?>

        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title"><a
                        href="<?php echo ROOT_HOST ?>shop?id=<?php echo $category['id'] . '&slug=' . $category['cat_slug'] ?>"><?php echo $category['name'] ?></a>
                </h4>
            </div>
        </div>

        <?php
		}
		?>
    </div>
    <!--/category-products-->
</div>