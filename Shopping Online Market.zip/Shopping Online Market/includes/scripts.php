<script src="<?php echo ROOT_HOST ?>js/jquery.js"></script>
<script src="<?php echo ROOT_HOST ?>js/bootstrap.min.js"></script>
<script src="<?php echo ROOT_HOST ?>js/jquery.scrollUp.min.js"></script>
<script src="<?php echo ROOT_HOST ?>js/jquery.prettyPhoto.js"></script>
<script src="<?php echo ROOT_HOST ?>js/main.js"></script>