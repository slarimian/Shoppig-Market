<?php
include 'includes/session.php';

if (isset($_POST['pay'])) {
    $_SESSION['pay'] = 1;
} else {
    header('location:' . ROOT_HOST);
}

if (!isset($_SESSION['user'])) {
    header('location:' . ROOT_HOST . 'login');
} else {
    $user_id = $_SESSION['user'];
}

$db->deleteWholeCart($user_id);

header('location:' . ROOT_HOST  . 'verify');
