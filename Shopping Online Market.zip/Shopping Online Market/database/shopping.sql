-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 10, 2023 at 11:07 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `quantity` int NOT NULL,
  `image` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `price` int NOT NULL,
  `amount` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `cat_slug` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `cat_slug`) VALUES
(1, 'SPORTSWEAR', 'sportswear'),
(2, 'MENS', 'mens'),
(3, 'WOMENS', 'tablets'),
(4, 'KIDS', 'kids'),
(5, 'FASHION', 'fashion'),
(6, 'HOUSEHOLDS', 'households'),
(7, 'INTERIORS', 'interiors'),
(8, 'PARTY WEAR', 'party-wear'),
(9, 'BAGS', 'bags'),
(10, 'SHOES', 'shoes');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int NOT NULL,
  `category_id` int NOT NULL,
  `name` text NOT NULL,
  `brand` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `slug` varchar(200) NOT NULL,
  `price` double NOT NULL,
  `availability` tinyint(1) NOT NULL DEFAULT '1',
  `photos` varchar(350) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `score` smallint NOT NULL DEFAULT '0',
  `new` tinyint(1) NOT NULL DEFAULT '0',
  `sale` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `brand`, `description`, `slug`, `price`, `availability`, `photos`, `score`, `new`, `sale`) VALUES
(30, 1, 'Napapijri Box logo t-shirt dress in black', 'Napapijri', 'Your new go-to\r\nBranded design\r\nCrew neck\r\nShort sleeves\r\nRegular fit', 'napapijri-box-logo-t-shirt-dress-in-black', 40, 1, '204331421-2.jpg,204331421-3.jpg,204331421-4.jpg', 3, 0, 0),
(31, 1, 'ASOS 4505 Icon yoga cami crop top with inner bra', 'ASOS 4505', 'Stretch in style\r\nInner bra design\r\nScoop neck\r\nAdjustable, back straps\r\nRacer back for unrestricted movement\r\nRegular fit', 'asos-4505-icon-yoga-cami-crop-top-with-inner-bra', 20, 1, '204416465-1-black.jpg,204416465-2.jpg,204416465-3.jpg', 4, 0, 0),
(32, 2, 'Men Slogan Graphic Tee', 'x', 'Color:\r\nWhite\r\nStyle:\r\nCasual\r\nPattern Type:\r\nSlogan\r\nNeckline:\r\nRound Neck\r\nSleeve Length:\r\nHalf Sleeve\r\nSleeve Type:\r\nDrop Shoulder\r\nLength:\r\nRegular\r\nFit Type:\r\nRegular Fit\r\nFabric:\r\nSlight Stretch\r\nMaterial:\r\nFabric\r\nComposition:\r\n100% Polyester\r\nCare Instructions:\r\nMachine wash or professional dry clean\r\nSheer:\r\nNo', 'Men-Slogan-Graphic-Tee', 10, 1, '16823264196d57df60f217301703c3369ea6d40e5f_thumbnail_600x.jpg,1682326427763ec54b2e1841c51604ea5946ba54b0_thumbnail_600x.jpeg,16823264254958fda4c0189ea1a79502afe58a20a2_thumbnail_600x.jpeg', 4, 0, 0),
(33, 2, 'Manfinity Homme Men Solid Button Up Shirt', 'x', 'Color:\r\nBlack\r\nStyle:\r\nCasual\r\nPattern Type:\r\nPlain\r\nType:\r\nShirt\r\nNeckline:\r\nCollar\r\nDetails:\r\nButton Front\r\nSleeve Length:\r\nShort Sleeve\r\nSleeve Type:\r\nRegular Sleeve\r\nLength:\r\nRegular\r\nFit Type:\r\nRegular Fit\r\nFabric:\r\nNon-Stretch\r\nMaterial:\r\nFabric\r\nComposition:\r\n100% Polyester\r\nCare Instructions:\r\nMachine wash or professional dry clean\r\nSheer:\r\nNo', 'Manfinity-Homme-Men-Solid-Button-Up-Shirt', 4, 1, '16856964733caa4821d9a74ab272ec8d4d51c23601_thumbnail_600x.jpg,168569647448fe6f597db80cd5237a4342d8a82e0a_thumbnail_600x.jpg,16856964773a4fe4786fdebd7fbd632d23268b5edf_thumbnail_600x.jpg', 3, 0, 0),
(34, 3, 'EZwear Solid Rib-knit Tube Top ', 'x', 'Color:\r\nApricot\r\nStyle:\r\nCasual\r\nPattern Type:\r\nPlain\r\nNeckline:\r\nStrapless\r\nSleeve Length:\r\nSleeveless\r\nDetails:\r\nRib-Knit, Cup Detail\r\nLength:\r\nRegular\r\nFit Type:\r\nSlim Fit\r\nFabric:\r\nSlight Stretch\r\nMaterial:\r\nKnitted Fabric\r\nComposition:\r\n93% Viscose, 7% Elastane\r\nCare Instructions:\r\nMachine wash or professional dry clean\r\nSheer:\r\nSemi-Sheer', 'EZwear-Solid-Rib-knit-Tube-Top', 5, 1, '168843668117d2e68db67a834d1ec2a0e3bcbdd11e_thumbnail_600x.jpg,1688436683267636706078a72e450d4f38074cb82d_thumbnail_600x.jpg,16884366915a107f3222200dabdb514fe27c46c855_thumbnail_600x.jpg', 5, 0, 0),
(35, 3, 'LUNE Button Detail Ruched Side Tank Top', 'x', 'Color:\r\nWhite\r\nStyle:\r\nCasual\r\nPattern Type:\r\nPlain\r\nType:\r\nTank\r\nNeckline:\r\nV neck\r\nDetails:\r\nButton, Ruched, Wrap\r\nLength:\r\nRegular\r\nFit Type:\r\nSlim Fit\r\nFabric:\r\nSlight Stretch\r\nMaterial:\r\nFabric\r\nComposition:\r\n65% Polyester, 30% Viscose, 5% Elastane\r\nCare Instructions:\r\nMachine wash or professional dry clean\r\nSheer:\r\nNo', 'LUNE-Button-Detail-Ruched-Side-Tank-Top', 7, 1, '1678110754b45cb815a2bea50f5ab157834fabb269_thumbnail_600x.jpg,16781107470baa8a049ef4d0573168d003500892b2_thumbnail_600x.jpg,1678110752d13ecee7775157aeb395e4989a08a9b4_thumbnail_600x.jpg', 4, 0, 0),
(36, 4, 'Girls Elastic Waist Rib-knit Flare Leg Pants', 'x', 'Color:\r\nBlack\r\nStyle:\r\nCasual\r\nPattern Type:\r\nPlain\r\nType:\r\nFlare Leg\r\nClosure Type:\r\nElastic Waist\r\nDetails:\r\nRib-Knit\r\nWaist Line:\r\nHigh Waist\r\nLength:\r\nLong\r\nFit Type:\r\nRegular Fit\r\nFabric:\r\nSlight Stretch\r\nMaterial:\r\nFabric\r\nComposition:\r\n95% Polyester, 5% Elastane\r\nCare Instructions:\r\nMachine wash or professional dry clean\r\nBody:\r\nUnlined\r\nSheer:\r\nNo', 'Girls-Elastic-Waist-Rib-knit-Flare-Leg-Pants', 4, 1, '1637890666fe83e7c6063cd2b0631ee810960d2049_thumbnail_600x.jpg,1637890667a5fe42d33d802465de24f5d00d840886_thumbnail_600x.jpg,1637890670399086090fd6c35e8b78b1482ef19479_thumbnail_600x.jpg', 4, 0, 0),
(37, 4, 'Toddler Boys Slogan Graphic Tee', 'x', 'Color:\r\nBlack\r\nStyle:\r\nCasual\r\nPattern Type:\r\nSlogan\r\nNeckline:\r\nRound Neck\r\nSleeve Length:\r\nShort Sleeve\r\nSleeve Type:\r\nRegular Sleeve\r\nLength:\r\nRegular\r\nFit Type:\r\nRegular Fit\r\nFabric:\r\nSlight Stretch\r\nMaterial:\r\nFabric\r\nComposition:\r\n100% Polyester\r\nCare Instructions:\r\nMachine wash or professional dry clean\r\nSheer:\r\nNo', 'Toddler-Boys-Slogan-Graphic-Tee', 2, 1, '16405684052f333de8fcfb41b800a57eac3d7d16c3_thumbnail_600x.jpg,1640568407ad4f557e20c5252cfce36bec9755b81f_thumbnail_600x.jpg,1640568409a178200ee3fc33a03a03d5b06f0c4d46_thumbnail_600x.jpg', 4, 0, 0),
(38, 5, 'EZwear High Waist Patch Detail Raw Cut Flare Leg Jeans', 'x', 'Color:\r\nMedium Wash\r\nPattern Type:\r\nPlain\r\nType:\r\nFlare Leg\r\nClosure Type:\r\nZipper Fly\r\nDetails:\r\nButton, Pocket, Zipper\r\nWaist Line:\r\nHigh Waist\r\nLength:\r\nLong\r\nFit Type:\r\nRegular Fit\r\nFabric:\r\nHigh Stretch\r\nMaterial:\r\nDenim\r\nComposition:\r\n70% Cotton, 28% Polyester, 2% Elastane\r\nCare Instructions:\r\nMachine wash, do not dry clean\r\nBody:\r\nUnlined\r\nSheer:\r\nNo', 'EZwear-High-Waist-Patch-Detail-Raw-Cut-Flare-Leg-Jeans', 14, 1, '1655775338bd8a94644c43d979cfdb4ce30c0df59b_thumbnail_600x.jpg,16575040033c909c50b4dc0b003487962f69dc072c_thumbnail_600x.jpg,1655775346cae0741e6b0047bc4fb8c9fcd2d91196_thumbnail_600x.jpg', 4, 0, 0),
(39, 5, 'EZwear Solid High Waist Flap Pocket Cargo Pants', 'x', 'Color:\r\nArmy Green\r\nStyle:\r\nCasual\r\nPattern Type:\r\nPlain\r\nType:\r\nCargo Pants\r\nClosure Type:\r\nElastic Waist\r\nDetails:\r\nPocket\r\nWaist Line:\r\nHigh Waist\r\nLength:\r\nLong\r\nFit Type:\r\nRegular Fit\r\nFabric:\r\nNon-Stretch\r\nMaterial:\r\nFabric\r\nComposition:\r\n100% Polyester\r\nCare Instructions:\r\nMachine wash or professional dry clean\r\nBody:\r\nUnlined\r\nSheer:\r\nNo', 'EZwear-Solid-High-Waist-Flap-Pocket-Cargo-Pants', 4, 1, '163263398748f50417f32fce68f8c3972549b4746c_thumbnail_600x.jpg,1632633973df96026bc43c6173b1b9ee31cfd11667_thumbnail_600x.jpg,1632633983c9bd0db55fe65041710b4c514f18a858_thumbnail_600x.jpg', 4, 0, 0),
(40, 5, 'Floral Print Butterfly Sleeve Ruffle Hem Dress', 'x', 'Color:\r\nMulticolor\r\nStyle:\r\nBoho\r\nPattern Type:\r\nFloral, All Over Print\r\nDetails:\r\nRuffle Hem, Tie Back\r\nNeckline:\r\nV neck\r\nType:\r\nA Line\r\nSleeve Length:\r\nShort Sleeve\r\nSleeve Type:\r\nFlounce Sleeve\r\nWaist Line:\r\nHigh Waist\r\nHem Shaped:\r\nLayered/Tiered\r\nLength:\r\nMaxi\r\nFit Type:\r\nRegular Fit\r\nFeatures:\r\nBreathable\r\nFabric:\r\nNon-Stretch\r\nMaterial:\r\nFabric\r\nComposition:\r\n100% Polyester\r\nCare Instructions:\r\nMachine wash or professional dry clean\r\nPockets:\r\nNo\r\nBody:\r\nNo\r\nChest pad:\r\nNo Padding\r\nBelt:\r\nNo\r\nSheer:\r\nNo', 'Floral-Print-Butterfly-Sleeve-Ruffle-Hem-Dress', 14, 1, '1688054622fa530cb451d89e68f95bd20db39113f0_thumbnail_600x.jpg,1688054618614edd5cd381d5a0c70e4df969e15047_thumbnail_600x.jpg,16880546280866c9ace467199214f8d3fb4f61359d_thumbnail_600x.jpg', 4, 0, 0),
(41, 6, 'SHEIN X Rosie Letter & Floral Print Sleep Top', 'x', 'Color:\r\nDusty Pink\r\nPattern Type:\r\nFloral, Letter\r\nLength:\r\nRegular\r\nNeckline:\r\nRound Neck\r\nSleeve Length:\r\nShort Sleeve\r\nSleeve Type:\r\nRegular Sleeve\r\nFit Type:\r\nLoose\r\nFabric:\r\nSlight Stretch\r\nMaterial:\r\nKnitted Fabric\r\nComposition:\r\n95% Polyester, 5% Elastane\r\nCare Instructions:\r\nMachine wash or professional dry clean\r\nSheer:\r\nNo', 'SHEIN-X-Rosie-Letter-Floral-Print-Sleep-Top', 5, 1, '1688447434cc7677d1a521613197c7b7d09e7bdd3a_thumbnail_600x.jpg,1688447437ef8f9b4e9fec399edfe85d7fb6e14cc6_thumbnail_600x.jpg,168844744004f372fda544c398336ac4f27bffcb07_thumbnail_600x.jpg', 5, 0, 0),
(42, 8, 'Mesh Insert Sequin Formal Dress ', 'x', 'Color:\r\nChampagne\r\nPattern Type:\r\nPlain\r\nType:\r\nA Line\r\nDetails:\r\nContrast Sequin, Zipper\r\nNeckline:\r\nDeep V Neck\r\nSleeve Length:\r\nThree Quarter Length Sleeve\r\nSleeve Type:\r\nRegular Sleeve\r\nLength:\r\nMaxi\r\nHem Shaped:\r\nFlared\r\nWaist Line:\r\nHigh Waist\r\nFit Type:\r\nRegular Fit\r\nFabric:\r\nHigh Stretch\r\nMaterial:\r\nSequins\r\nComposition:\r\n100% Polyester\r\nCare Instructions:\r\nHand wash,do not dry clean\r\nPockets:\r\nNo\r\nBody:\r\nYes\r\nBelt:\r\nNo\r\nSheer:\r\nNo\r\nChest pad:\r\nYes\r\nLining:\r\n100% Polyester\r\nLined For Added Warmth:\r\nNo', 'Mesh-Insert-Sequin-Formal-Dress', 28, 1, '16837251395d844647422bfeaf909d0e6a78ab4d02_thumbnail_600x.jpg,1683725143e4b3ae312c5c0adf29bb212ab22f1f54_thumbnail_600x.jpg,168372515644e5066537b0c69a5ab201140ce6749d_thumbnail_600x.jpg', 5, 0, 0),
(43, 7, 'SHEIN EZwear Plus Ribbed Knit Cardigan Without Cami Top', 'x', 'Color:\r\nWhite\r\nStyle:\r\nCasual\r\nPattern Type:\r\nPlain\r\nDetails:\r\nBolero\r\nSleeve Length:\r\nLong Sleeve\r\nSleeve Type:\r\nRaglan Sleeve\r\nLength:\r\nCrop\r\nFit Type:\r\nRegular Fit\r\nFabric:\r\nSlight Stretch\r\nMaterial:\r\nWorsted\r\nComposition:\r\n100% Acrylic\r\nCare Instructions:\r\nHand wash or professional dry clean\r\nSheer:\r\nNo', 'SHEIN-EZwear-Plus-Ribbed-Knit-Cardigan-Without-Cami-Top', 12, 1, '168714148062e79304886ee5a6872f6969e02f5ca6_thumbnail_600x.jpg,1687141477314fab31c472f88320cda328dc3dce3e_thumbnail_600x.jpg,1687141485c173eb3cbc6d59a2ddce410db3141aa3_thumbnail_600x.jpg', 5, 0, 0),
(44, 9, 'Vintage Design Hobo Bag', 'x', 'Color:\r\nCoffee Brown\r\nBag Size:\r\nSmall\r\nPattern Type:\r\nPlain\r\nStrap Type:\r\nAdjustable\r\nStyle:\r\nElegant\r\nType:\r\nHobo Bag\r\nMaterial:\r\nPU', 'Vintage-Design-Hobo-Bag', 6, 1, '167573470648c518d4619a30abd093142602c8723e_thumbnail_600x.jpg,16757347008b8af45ccf424571d734a28456d1a9b2_thumbnail_600x.jpg,1675734704b2fe6d9bc25855554a20a249e6fcf6d5_thumbnail_600x.jpg', 5, 0, 0),
(45, 10, 'Women White Colorblock Lace-Up Front Skate Shoes', 'x', 'Color:\r\nWhite\r\nType:\r\nSkate Shoes\r\nStyle:\r\nPreppy\r\nToe:\r\nRound Toe\r\nPattern Type:\r\nColorblock\r\nStrap Type:\r\nLace Up\r\nUpper Material:\r\nPU Leather\r\nLining Material:\r\nPU Leather\r\nPower Supply:\r\nNo', 'Women-White-Colorblock-Lace-Up-Front-Skate-Shoes', 12, 1, '1631675022248712f1d1882f7010a39aae0f735ad2_thumbnail_600x.jpg,1631675026a72c0d57552eadd2b7d6449ca446a708_thumbnail_600x.jpg,1631675044a91c1616e1bc2dbeeb3ca68c814718a9_thumbnail_600x.jpg', 5, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `type` int NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `type`, `firstname`, `lastname`) VALUES
(1, 'sepide@gmail.com', '$2y$10$eCrCXy3cv9kYpGlFJYzQgOBmqFyrNc6yvHHnw4HU8kUTzIUnB36M2', 0, 'sepide', 'laremeian');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
