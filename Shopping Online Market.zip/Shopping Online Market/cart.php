<?php
$page = "Cart";
include 'includes/session.php';
include 'includes/head.php';

if (!isset($_SESSION['user'])) {
	header('location:' . ROOT_HOST . 'login');
} else {
	$user_id = $_SESSION['user'];
}

if (isset($_GET['id']) && isset($_GET['qut'])) {
	$db->addToCart($user_id, $_GET['id'], $_GET['qut']);
	header('location:' . ROOT_HOST . 'cart');
}

if (isset($_GET['id']) && isset($_GET['del'])) {
	$db->deleteSingleCartItem($user_id, $_GET['id']);
	header('location:' . ROOT_HOST . 'cart');
}

?>

<body>
	<?php include 'includes/header.php'; ?>


	<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
					<li><a href="<?php echo ROOT_HOST ?>">Home</a></li>
					<li class="active">Shopping Cart</li>
				</ol>
			</div>
			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image">Item</td>
							<td class="description"></td>
							<td class="price">Price</td>
							<td class="quantity">Quantity</td>
							<td class="total">Total</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
						<?php
						$items = $db->getShoppingCart($user_id);
						$sum = 0;
						foreach ($items as $product) {

							$sum += $product['amount'];
							if (strlen($product['name']) > 30) {
								$p_name = substr($product['name'], 0, 27) . "...";
							} else {
								$p_name = $product['name'];
							}
						?>


							<tr>
								<td class="cart_product">
									<a href=""><img src="<?php echo ROOT_HOST ?>images/product-details/<?php echo $product['image']; ?>" alt=""></a>
								</td>
								<td class="cart_description">
									<h4><a href=""><?php echo $p_name; ?></a></h4>
									<p>Web ID:esp153 <?php echo $product['id'] ?></p>
								</td>
								<td class="cart_price">
									<p><?php echo $product['price'] . " €"; ?></p>
								</td>
								<td class="cart_price">
									<p><?php echo $product['quantity'] ?></p>
								</td>
								<td class="cart_total">
									<p class="cart_total_price"><?php echo $product['amount'] . " €"; ?></p>
								</td>
								<td class="cart_delete">
									<a class="cart_quantity_delete" href="<?php echo ROOT_HOST ?>cart?id=<?php echo $product['id'] ?>&del"><i class="fa fa-times"></i></a>
								</td>
							</tr>


						<?php
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</section>
	<!--/#cart_items-->

	<section id="do_action">
		<div class="container">
			<div class="row">
				<div class="col-sm-6">
					<div class="total_area">
						<ul>
							<li>Cart Sub Total <span><?php echo $sum . " €"; ?></span></li>
							<li>Shipping Cost <span>Free</span></li>
							<li>Total <span><?php echo $sum . " €"; ?></span></li>
						</ul>

						<?php
						if ($sum != 0) {
						?>
							<form action="<?php echo ROOT_HOST ?>checkout-controller.php" method="POST">
								<input type="hidden" name="checkout" value="1">
								<button type="submit" class="btn btn-default check_out">Check Out</button>
							</form>

						<?php
						} ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--/#do_action-->

	<?php
	include 'includes/footer.php';
	include 'includes/scripts.php';
	?>
</body>

</html>